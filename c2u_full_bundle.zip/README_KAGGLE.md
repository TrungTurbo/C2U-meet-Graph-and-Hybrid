# HƯỚNG DẪN THỰC THI TOÀN TRÌNH C2U IN RAG TRÊN KAGGLE GPU (T4/P100)

Tài liệu này hướng dẫn chi tiết quy trình chạy toàn bộ 48 unit thử nghiệm (4 dataset × 3 seed × 4 encoder) trên Kaggle GPU một cách đơn giản, tin cậy và không xảy ra lỗi thiếu file.

---

## 1. Chuẩn Bị & Tải Gói Dữ Liệu Lên Kaggle

Thư mục dự án đã đóng gói sẵn file nén toàn diện **`c2u_full_bundle.zip`** (~11.9 MB), bao gồm:
1. **`processed_splits/`**: Toàn bộ 15 thư mục split đã chuẩn hóa không rò rỉ (12 single + 3 multi-concept). Không cần tải dataset thô 3.8GB lên Kaggle!
2. **`src/`**: Mã nguồn module hóa (`split_units.py`, `encode_cache.py`, `acr_dataset.py`, `acr_model.py`, `train_acr.py`, `c2u_operator.py`, `evaluate.py`).
3. **`configs/`**: Toàn bộ file YAML từ khóa và danh mục đã khóa.
4. **`manifests/`**: Các file manifest SHA256 và `encoders.json` ghim revision.
5. **`tests/`**: Bộ kiểm thử toàn vẹn dữ liệu `test_data_integrity.py` và dry-run toán học.
6. **`run_kaggle.py`**: Kịch bản điều phối tự động từ A-Z.

### Cách tải lên Kaggle:
1. Vào [Kaggle](https://www.kaggle.com/) -> Chọn **Datasets** -> **New Dataset**.
2. Đặt tiêu đề (Title): `c2u-bundle`.
3. Kéo thả file `c2u_full_bundle.zip` vào và nhấn **Create**.
4. Mở Notebook mới trên Kaggle:
   - Chọn Accelerator: **GPU T4 x 2** hoặc **GPU P100**.
   - Bật **Internet**: **On** (trong mục Settings bên phải để tải weights encoder).
   - Nhấn **Add Input** -> Chọn dataset `c2u-bundle` vừa tạo.

---

## 2. Các Cells Thực Thi Trong Kaggle Notebook

### CELL 1: Kiểm Tra Phần Cứng GPU & Cài Đặt Dependencies
```python
import torch
print(f"CUDA Available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU Model: {torch.cuda.get_device_name(0)}")
    print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / (1024**3):.2f} GB")

!pip install -q sentence-transformers concept-erasure rank_bm25 scikit-learn
```

---

### CELL 2: Sao Chép Dữ Liệu & Mã Nguồn Sang Thư Mục Làm Việc (/kaggle/working)
```python
import os, shutil

# Kaggle tự động giải nén file zip khi tạo dataset thành các thư mục
input_dir = None
for root, dirs, files in os.walk("/kaggle/input"):
    if "processed_splits" in dirs and "src" in dirs:
        input_dir = root
        break

assert input_dir, "Không tìm thấy dữ liệu trong /kaggle/input! Vui lòng kiểm tra lại dataset đã add."
print(f"Đã tìm thấy dữ liệu tại: {input_dir}")

for item in ["src", "configs", "manifests", "processed_splits", "tests", "run_kaggle.py", "requirements.txt"]:
    s = os.path.join(input_dir, item)
    d = os.path.join("/kaggle/working", item)
    if os.path.exists(s):
        if os.path.isdir(s):
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            shutil.copy2(s, d)
        print(f"-> Đã copy {item}")

# Tạo sẵn thư mục lưu kết quả
os.makedirs("/kaggle/working/cache_embeddings", exist_ok=True)
os.makedirs("/kaggle/working/checkpoints", exist_ok=True)

print("\n[Thành công] Toàn bộ mã nguồn và 15 split đã sẵn sàng tại /kaggle/working!")
!ls -la /kaggle/working
```

---

### CELL 3: Kiểm Tra Toàn Vẹn & Rời Rạc Dữ Liệu (Gói 1.4)
```python
%cd /kaggle/working
# Chạy kiểm thử toàn vẹn 15 split và manifest (chạy mượt mà, không lỗi)
!python tests/test_data_integrity.py
```

---

### CELL 4: Chạy Pipeline Toàn Diện (Giai Đoạn 1 Cache & Giai Đoạn 2 Huấn Luyện ACR)
```python
%cd /kaggle/working
# Chạy toàn bộ 4 dataset x 3 seed x 4 encoder = 48 units trên GPU
!python run_kaggle.py --dataset all --seed 0 --encoder all --max_epochs 10
```

---

### CELL 5: Đóng Gói Toàn Bộ Checkpoints & Cache Để Tải Về
```python
%cd /kaggle/working
import zipfile, os

zip_name = "c2u_results_and_checkpoints.zip"
with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for folder in ["checkpoints", "cache_embeddings"]:
        if os.path.exists(folder):
            for root, dirs, files in os.walk(folder):
                for f in files:
                    fp = os.path.join(root, f)
                    zipf.write(fp, fp)

print(f"[Done] Đã đóng gói toàn bộ kết quả vào: /kaggle/working/{zip_name}")
print(f"Dung lượng: {os.path.getsize(zip_name) / (1024*1024):.2f} MB")
```

---

### CELL 6: Nén Kết Quả & Checkpoints Để Tải Về Máy
```python
import os, zipfile

os.makedirs("/kaggle/working/results", exist_ok=True)
output_zip = "/kaggle/working/c2u_results_and_checkpoints.zip"

with zipfile.ZipFile(output_zip, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    for target_dir in ["checkpoints", "cache_embeddings", "manifests"]:
        if os.path.exists(target_dir):
            for root, dirs, files in os.walk(target_dir):
                for f in files:
                    fp = os.path.join(root, f)
                    zf.write(fp, os.path.relpath(fp, "/kaggle/working"))

print(f"[Done] Đã đóng gói toàn bộ kết quả vào: {output_zip}")
print(f"Dung lượng: {os.path.getsize(output_zip) / (1024*1024):.2f} MB")
```
